package br.com.fiapride.model;

public class MotoEletrica extends Veiculo {
    
    private boolean isEletrica;

    public MotoEletrica(String placa, String modelo) {
        super(placa, modelo);        
    }

    @Override
    public void exibirTipo() {
        System.out.println("Sou uma Moto Eletrica");
    }
    
    @Override
    public String calcularAutonomia() {
        double kmRestante = this.getNivelCombustivel() * 35.0; 
        return "Autonomia: " + kmRestante + " km (Consumo de 35 km/l).";
    }

    public boolean isEletrica() {
        return this.isEletrica;
    }

    public void setIsEletrica (boolean isEletrica) {
        this.isEletrica = isEletrica;
    }
}