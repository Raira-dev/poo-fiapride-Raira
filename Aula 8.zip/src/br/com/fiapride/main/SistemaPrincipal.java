package br.com.fiapride.main;

import br.com.fiapride.model.Carro;
import br.com.fiapride.model.Moto;
import br.com.fiapride.model.Veiculo;
import br.com.fiapride.model.MotoEletrica;


public class SistemaPrincipal {
    public static void main(String[] args) {
        
        System.out.println("=== FIAPRIDE: Teste de Classes Abstratas ===");
        System.out.println();
        
        Veiculo taxi = new Carro("ABC-1234", "Chevrolet Onix");
        Veiculo mototaxi = new Moto("MOT-9999", "Honda Biz");
        Veiculo motopessoal = new MotoEletrica("FIA-555","Honda U-GO Scooter Eletrica");
        
        // TESTE 3: Chamar método abstrato implementado
        System.out.println("Identificação dos Veículos:");
        taxi.exibirTipo();      // Saída: Sou um Carro
        mototaxi.exibirTipo();  // Saída: Sou uma Moto
        motopessoal.exibirTipo();  // Saída: Sou uma Moto Eletrica
        
        System.out.println();
        System.out.println("=== Polimorfismo com Classe Abstrata ===");
        
        Veiculo[] frota = new Veiculo[] {
            new Carro("CAR-1111", "Fiat Uno"),
            new Moto("MOT-2222", "Yamaha"),
            new Carro("CAR-3333", "Honda Civic")
        };
        
        for (Veiculo v : frota) {
            v.exibirTipo();
            System.out.println("---");
        }
    }
}
